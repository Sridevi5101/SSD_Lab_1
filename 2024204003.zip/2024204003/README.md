Hello, Sridevi Here!
I am assuming that when the script is executed, - a copy of the files (access.log and power_levels.txt) exists in the folder.
