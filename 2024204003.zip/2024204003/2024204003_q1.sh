#!/bin/bash
awk '/POST/ && /404/' access.log
